#pragma once
#include <fstream>
#include "FilmData.h"

using namespace std;


vector<FilmData> fileData(string fileName, int size);
  
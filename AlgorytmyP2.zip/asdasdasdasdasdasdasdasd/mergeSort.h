#pragma once

#include "FilmData.h"



void merge(vector<FilmData>& arr, int left, int mid, int right);
void mergeSort(vector<FilmData>& arr, int left, int right);


#pragma once
#include "FilmData.h"

void bucketSort(vector<FilmData>& arr);

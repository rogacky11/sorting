#pragma once

#include "FilmData.h"

void quickSort(vector<FilmData>& arr, int left, int right);
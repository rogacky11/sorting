#pragma once
#include "FilmData.h"

double average(vector<FilmData>& data);
double median(vector<FilmData>& data);
